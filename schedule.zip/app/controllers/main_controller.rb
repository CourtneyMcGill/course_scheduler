class MainController < ApplicationController
  def index
  end
end

