class CenteralController < ApplicationController
  def index
  end
end
