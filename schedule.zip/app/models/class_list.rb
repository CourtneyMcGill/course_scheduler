class ClassList < ActiveRecord::Base
end
