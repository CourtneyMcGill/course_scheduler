require 'rails_helper'

RSpec.describe PlansStudentsController, type: :controller do

end
