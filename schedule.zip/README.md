# course_scheduler
a comprehensive course planning and registration tool
testing
